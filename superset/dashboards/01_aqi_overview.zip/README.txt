Dashboard: AQI Overview — Vietnam
Slug: aqi-overview-vietnam

This ZIP is a Superset dashboard stub — mart tables may not be populated yet.

To create the actual dashboard:
1. docker compose up -d superset
2. docker compose run airflow-scheduler airflow dags trigger dag_transform
3. Wait ~5 min for dbt to populate mart tables
4. docker compose exec superset python /app/setup_dashboards.py

Charts: 5
  - AQI by City (Table)
  - Current AQI — Max (Big Number)
  - Vietnam — AQI Stations Map
  - Stations — Active Count
  - Top 10 Worst AQI Stations

Query tables:
  - fct_hourly_aqi
  - dim_locations
  - fct_daily_aqi_summary
  - mart_air_quality__dashboard
  - raw_aqicn_forecast

Vietnam filter: lat 8-24, lon 102-110
EPA color scale: Good(0-50) Green | Moderate(51-100) Yellow | USG(101-150) Orange |
  Unhealthy(151-200) Red | Very Unhealthy(201-300) Purple | Hazardous(301-500) Maroon
